class ParadigmConfig:
    def __init__(self):
        self.paradigm_name = None
        self.save_time = None
        self.background_frame_path = None
        self.stimulation_frames_path = []
        self.stim_target_rect_set = []
        self.string_positions = []