class ParadigmConfig:
    def __init__(self):
        self.paradigm_name = None
        self.save_time = None
        self.background_frame_path = None
        self.stimulation_frames_path = []
        self.stimTargetRectSet = []
        self.stringPositions = []