from StimulationSystem.StimulationProcess.StimulationController import StimulationController


controller = StimulationController()
