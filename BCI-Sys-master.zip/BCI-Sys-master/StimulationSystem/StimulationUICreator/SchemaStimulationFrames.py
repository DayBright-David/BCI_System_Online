from StimulationSystem.StimulationUICreator.BasicSchemaStimulationFrames import BasicSchemaStimulationFrames


class SchemaStimulationFrames(BasicSchemaStimulationFrames):
    def __init__(self):
        BasicSchemaStimulationFrames.__init__(self)


if __name__ == '__main__':
    t = SchemaStimulationFrames()
