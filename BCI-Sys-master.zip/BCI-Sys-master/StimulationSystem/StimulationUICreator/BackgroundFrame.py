class BackgroubdFrame:
    def __init__(self):
        self.base_framework = None


if __name__ == '__main__':
    t = BackgroubdFrame()
