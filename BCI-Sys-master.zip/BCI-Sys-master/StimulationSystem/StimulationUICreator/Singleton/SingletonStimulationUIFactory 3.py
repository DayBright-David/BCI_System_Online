from StimulationSystem.StimulationUICreator.StimulationUIFactory import StimulationUIFactory


factory_StimulationUIFactory = StimulationUIFactory()
