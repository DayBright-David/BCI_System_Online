class BasicSchemaStimulationFrames:
    def __init__(self):
        self.frameSet = None
        self.initial_frame = None
        self.stimTargetRectSet = None
        self.stringPositions = None
