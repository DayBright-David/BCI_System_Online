class BasicSchemaStimulationFrames:
    def __init__(self):
        self.frame_set = None
        self.initial_frame = None
        self.stim_target_rect_set = None
        self.string_positions = None
