class PreprocessFilter:
    def __init__(self):
        self.B = None
        self.A = None
