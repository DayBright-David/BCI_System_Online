class SchemaProcessInformation:
    def __init__(self):
        self.targetTable = None
